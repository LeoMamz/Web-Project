<?php
function post_data($url, $postData) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_PORT, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Content-Length: ' . strlen($postData))
    );
    //ob_start();
    curl_exec($ch);
    $return_content = ob_get_contents();
    ob_end_clean();
    return  $return_content;
}

$url ="";
$type_sell=4;
$sell_request=json_encode(array('user_id'=>$_COOKIE['user'],'type'=>$type_sell));
$sell=json_decode(post_data($url,$sell_request));
$type_buy=5;
$buy_request=json_encode(array('user_id'=>$_COOKIE['user'],'type'=>$type_buy));
$buy=json_decode(post_data($url,$buy_request));
$type_result=6;
$result_request=json_encode(array('user_id'=>$_COOKIE['user'],'type'=>$type_result));
$result=json_decode(post_data($url,$result_request));
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>交易客户端-交易结果</title>
    <meta name="keywords"  content="设置关键词..." />
    <meta name="description" content="设置描述..." />
    <meta name="author" content="DeathGhost" />
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <link rel="icon" href="images/icon/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <script src="javascript/jquery.js"></script>
    <script src="javascript/plug-ins/customScrollbar.min.js"></script>
    <script src="javascript/plug-ins/echarts.min.js"></script>
    <script src="javascript/plug-ins/layerUi/layer.js"></script>
    <script src="editor/ueditor.config.js"></script>
    <script src="editor/ueditor.all.js"></script>
    <script src="javascript/plug-ins/pagination.js"></script>
    <script src="javascript/public.js"></script>
</head>
<body>
<div class="main-wrap">
    <div class="side-nav">
        <div class="side-logo">
            <div class="logo">
				<span class="logo-ico">
					<i class="i-l-1"></i>
					<i class="i-l-2"></i>
					<i class="i-l-3"></i>
				</span>
                <strong>股票交易客户端</strong>
            </div>
        </div>

        <nav class="side-menu content mCustomScrollbar" data-mcs-theme="minimal-dark">
            <h2>
                <a href="index.html" class="InitialPage"><i class="icon-dashboard"></i>首页</a>
            </h2>
            <ul>
                <li>
                    <dl>
                        <dt>
                            <i class="icon-columns"></i>信息查询<i class="icon-angle-right"></i>
                        </dt>
                        <dd>
                            <a href="capital-account.html">资金账户信息</a>
                        </dd>
                        <dd>
                            <a href="securities-account.html">证券账户信息</a>
                        </dd>
                    </dl>
                </li>
                <li>
                    <dl>
                        <dt>
                            <i class="icon-columns"></i>股票信息<i class="icon-angle-right"></i>
                        </dt>
                        <dd>
                            <a href="searchstock.html">股票查询</a>
                        </dd>
                        <dd>
                            <a href="result.html">交易结果</a>
                        </dd>
                    </dl>
                </li>
                <li>
                    <dl>
                        <dt>
                            <i class="icon-star"></i>股票交易<i class="icon-angle-right"></i>
                        </dt>
                        <dd>
                            <a href="buystock.html">购买股票</a>
                        </dd>
                        <dd>
                            <a href="sellstock.html">出售股票</a>
                        </dd>
                    </dl>
                </li>
                <li>
                    <dl>
                        <dt>
                            <i class="icon-fighter-jet"></i>价格提醒<i class="icon-angle-right"></i>
                        </dt>
                        <dd>
                            <a href="remember.html">查看提醒</a>
                        </dd>
                    </dl>
                </li>
            </ul>
        </nav>

        <footer class="side-footer">欢迎使用交易客户端，祝您生活愉快</footer>

    </div>
    <div class="content-wrap">
        <header class="top-hd">
            <div class="hd-lt">
                <a class="icon-reorder"></a>
            </div>
            <div class="hd-rt">
                <ul>
                    <li>
                        <a><i class="icon-user"></i>用户:<em><?php echo $_COOKIE['user']?></em></a>
                    </li>
                    <li>
                        <a><i class="icon-bell-alt"></i>系统消息</a>
                    </li>
                    <li>
                        <a><i class="icon-random"></i>修改密码</a>
                    </li>
                    <li>
                        <a href="javascript:void(0)" id="JsSignOut"><i class="icon-signout"></i>安全退出</a>
                    </li>
                </ul>
            </div>
        </header>
<main class="main-cont content mCustomScrollbar">
    <div class="page-wrap">
        <!--开始::内容-->
        <section class="page-hd">
            <header>
                <h2 class="title">交易结果</h2>
                <p class="title-description">
                    在这里查看您的历史交易。
                </p>
            </header>
            <hr>
        </section>
        <div class="panel panel-default">
            <!--<div class="panel-hd">按钮</div>-->
            <div class="panel-bd">
                <div class="card">
                    <div class="card-header">
                        <ul class="tab-nav">
                            <li class="active">出售中</li>
                            <li>购买中</li>
                            <li>交易完成</li>
                        </ul>
                    </div>
                    <div class="tab-cont" style="display: block;">
                        <?php
                            echo'<table class="table table-bordered table-striped table-hover">
                                <thead><tr>
                                <th>出售时间</th><th>股票代码</th><th>出售单价</th><th>出售数量</th><th>出售总额</th><th>操作</th>
                                </tr></thead><tbody>';
                            $count=0;
                            $count_sell=count($sell);
                            for(;$count<=$count_sell;$count++){
                                $sell_sum=$sell[$count]->price*$sell[$count]->number;
                                    echo '<form action="undo.php" method="post">';
                                    echo'<tr class="cen">';
                                    echo'<td>'.$sell[$count]->date.'</td>';
                                    echo'<td>'.$sell[$count]->stock_id.'</td>';
                                    echo'<td>'.$sell[$count]->stock_price.'</td>';
                                    echo'<td>'.$sell[$count]->stock_number.'</td>';
                                    echo'<td>'.$sell_sum.'</td>';
                                    echo'<td><button name="sell" title="撤回" class="mr-5" type="submit" value=" '.$sell[$count].'">撤回</button></td></tr>';
                                    echo '</form>';
                                }
                                echo'</tbody></table>';
                         ?>
							</div>
							<div class="tab-cont">
                                <?php
                                echo'<table class="table table-bordered table-striped table-hover">
                                <thead><tr>
                                <th>购买时间</th><th>股票代码</th><th>购买单价</th><th>购买数量</th><th>购买总额</th><th>操作</th>
                                </tr></thead><tbody>';
                                $count=0;
                                $count_buy=count($sell);
                                for(;$count<=$count_buy;$count++){
                                    $buy_sum=$buy[$count]->price*$buy[$count]->number;
                                    echo '<form action="undo.php" method="post">';
                                    echo'<tr class="cen">';
                                    echo'<td>'.$buy[$count]->date.'</td>';
                                    echo'<td>'.$buy[$count]->stock_id.'</td>';
                                    echo'<td>'.$buy[$count]->stock_price.'</td>';
                                    echo'<td>'.$buy[$count]->stock_number.'</td>';
                                    echo'<td>'.$buy_sum.'</td>';
                                    echo'<td><button name="buy" title="撤回" class="mr-5" type="submit" value=" '.$buy[$count].'">撤回</button></td></tr>';
                                    echo '</form>';
                                }
                                echo'</tbody></table>';
                                ?>
                            </div>
							<div class="tab-cont">
                                <?php
                                echo'<table class="table table-bordered table-striped table-hover">
                                <thead><tr>
                                <th>成交时间</th><th>交易类型</th><th>股票代码</th><th>成交单价</th><th>成交数量</th><th>成交总额</th>
                                </tr></thead><tbody>';
                                $count=0;
                                $count_result=count($result);
                                for(;$count<=$count_result;$count++){
                                    $result_sum=$result[$count]->price*$result[$count]->number;
                                    if($_COOKIE['user']==$result[$count]->purchaser){
                                        $result[$count]->type='购买';
                                    }
                                    else $result[$count]->type='出售';
                                    echo'<tr class="cen">';
                                    echo'<td>'.$result[$count]->date.'</td>';
                                    echo'<td>'.$result[$count]->type.'</td>';
                                    echo'<td>'.$result[$count]->stock_id.'</td>';
                                    echo'<td>'.$result[$count]->stock_price.'</td>';
                                    echo'<td>'.$result[$count]->stock_number.'</td>';
                                    echo'<td>'.$result_sum.'</td>';
                                }
                                echo'</tbody></table>';
                                ?>
                            </div>
						</div>
					</div>
				</div>
				<!--开始::结束-->
			</div>
		</main>
		<footer class="btm-ft">
			<p class="clear">
				<span class="fl">©Copyright 2016 <a href="#" title="DeathGhost" target="_blank">DeathGhost.cn</a></span>
				<span class="fr text-info">
					<em class="uppercase">
						<i class="icon-user"></i>
author:deathghost
</em> |
					<em class="uppercase"><i class="icon-envelope-alt"></i>
更多模板： <a href="http://www.mycodes.net/" target="_blank">源码之家</a>
					</em>
					<a onclick="reciprocate()" class="text-primary"><i class="icon-qrcode"></i>捐赠</a>
				</span>
			</p>
		</footer>
	</div>
</div>
</body>
</html>