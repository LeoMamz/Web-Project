<?php
function post_data($url, $postData) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_PORT, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Content-Length: ' . strlen($postData))
    );
    // ob_start();
    $return_content = curl_exec($ch);
    curl_close($ch);
    //ob_end_clean();
    return  $return_content;
}

$url="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['buy'])) {
        $arr = $_POST['buy'];
        $data =array("stock_id"=>$arr->stock_id,"stock_price"=>$arr->stock_price,"stock_number"=>$arr->stock_number,"user_id"=>$_COOKIE['user'],"date"=>$arr->date,"type"=>3);
        post_data($url,$data);
    }
    if (isset($_POST['sell'])) {
        $arr = $_POST['sell'];
        $data =array("stock_id"=>$arr->stock_id,"stock_price"=>$arr->stock_price,"stock_number"=>$arr->stock_number,"user_id"=>$_COOKIE['user'],"date"=>$arr->date,"type"=>2);
        post_data($url,$data);
    }
}