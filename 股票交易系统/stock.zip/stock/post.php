<?php
function http_post_data($url, $data_string) {

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Content-Length: ' . strlen($data_string))
    );

    $return_content = curl_exec($ch);

    curl_close($ch);

    return  $return_content;
}

$url  = "http://localhost/stoc/test14.php";
$data = json_encode(array('a'=>"shoudaoqinghuida", 'b'=>2));

//list($return_code, $return_content) = http_post_data($url, $data);
$aaa = http_post_data($url, $data);
//print_r($aaa);
//echo $aaa;

$ccc=json_decode($aaa);
print_r($ccc);
//echo $ccc->b;

